package bg.sofia.uni.fmi.mjt.spellchecker;

public record Pair<K, V>(K key, V value) {
}

